public interface IProgram
{
    public void run(String[] args);
}

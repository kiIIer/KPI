import picocli.CommandLine;

public interface ICLIInitializer
{
    public CommandLine initialize();
}

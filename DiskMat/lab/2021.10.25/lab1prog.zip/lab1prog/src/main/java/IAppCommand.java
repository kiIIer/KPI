public interface IAppCommand
{
    public Integer call() throws Exception;
}

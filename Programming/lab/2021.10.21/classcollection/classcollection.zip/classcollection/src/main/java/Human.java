public class Human {
    private int age;
    private double height;
    private double weight;

    public void setAge(int age) {
        positiveValidator(age);
        this.age = age;
    }

    public int getAge(){
        return this.age;
    }

    public void setHeight(double height) {
        positiveValidator(height);
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setWeight(double weight) {
        positiveValidator(weight);
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public Human(int age, double height, double weight) {
        positiveValidator(age);
        positiveValidator(height);
        positiveValidator(weight);
        this.age = age;
        this.height = height;
        this.weight = weight;
    }

    private void positiveValidator(double a){
        if(a < 0){
            throw new IllegalArgumentException("Values cannot be negative");
        }
    }

    @Override
    public String toString(){
        return String.format("", age, height, weight);
    }
}
